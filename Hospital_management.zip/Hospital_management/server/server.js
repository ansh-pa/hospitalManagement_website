// server.js
const express = require('express');
const db = require('./config/database.js'); // Using require for CommonJS
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(express.json()); // For parsing application/json
app.use(express.urlencoded({ extended: true })); // For parsing application/x-www-form-urlencoded

// Middleware
app.use(cors()); // Enable CORS
app.use(bodyParser.json()); // Parse JSON request body

// Serve static files like HTML, CSS, JS from the 'public' folder
app.use(express.static('public'));


app.get('/api/users', (req, res) => {
    console.log(req);
    const sql = 'SELECT * FROM users';

    db.all(sql, [], (err, rows) => {
        if (err) {
            console.error('Error fetching users:', err.message); // More descriptive error message
            return res.status(500).json({ error: 'Database error: ' + err.message }); // Clearer error message in response
        }
        res.json(rows); // Send all rows as JSON response
    });
});


// Start the server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
