let userData = {
    username: '',
    contact: '',
    email: '',
    password: ''
};

let signupForm = document.getElementById('signup');

let userName = document.getElementById('userName');
let userNameErrMsg = document.getElementById('userNameErrMsg');

let contactNumber = document.getElementById('contactNumber');
let contactNumberErrMsg = document.getElementById('contactNumberErrMsg');

let emailAddress = document.getElementById('emailAddress');
let emailAddressErrMsg = document.getElementById('emailAddressErrMsg');

let password = document.getElementById('password');
let passwordErrMsg = document.getElementById('passwordErrMsg');

let confirmPassword = document.getElementById('confirmPassword');
let confirmPasswordErrMsg = document.getElementById('confirmPasswordErrMsg');




function validateUsername(username) {
    if (!username) return 'Username is required.';
    if (username.length < 3) return 'Username must be at least 3 characters.';
    if (!/^[a-zA-Z0-9._-]+$/.test(username)) return 'Username can only contain letters, numbers, ".", "_", and "-".';
    return '';
}

function validateContact(contact) {
    if (!contact) return 'Contact number is required.';
    if (!/^\d{10}$/.test(contact)) return 'Contact number must be exactly 10 digits.';
    return '';
}

function validateEmail(email) {
    if (!email) return 'Email is required.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return 'Enter a valid email address.';
    return '';
}

function validatePassword(password) {
    if (!password) return 'Password is required.';
    if (password.length < 8) return 'Password must be at least 8 characters.';
    if (!/[A-Z]/.test(password) || !/[a-z]/.test(password) || !/\d/.test(password)) {
        return 'Password must contain uppercase, lowercase, and a number.';
    }
    return '';
}

function validateConfirmPassword(password, confirmPassword) {
    if (!confirmPassword) return 'Please confirm your password.';
    if (password !== confirmPassword) return 'Passwords do not match.';
    return '';
}





signupForm.addEventListener('submit', function (event) {
    event.preventDefault();

    let isFormValid = true;

    // Username Validation
    const usernameError = validateUsername(userName.value.trim());
    userNameErrMsg.textContent = usernameError;
    if (usernameError) isFormValid = false;

    // Contact Number Validation
    const contactError = validateContact(contactNumber.value.trim());
    contactNumberErrMsg.textContent = contactError;
    if (contactError) isFormValid = false;

    // Email Validation
    const emailError = validateEmail(emailAddress.value.trim());
    emailAddressErrMsg.textContent = emailError;
    if (emailError) isFormValid = false;

    // Password Validation
    const passwordError = validatePassword(password.value.trim());
    passwordErrMsg.textContent = passwordError;
    if (passwordError) isFormValid = false;

    // Confirm Password Validation
    const confirmPasswordError = validateConfirmPassword(password.value.trim(), confirmPassword.value.trim());
    confirmPasswordErrMsg.textContent = confirmPasswordError;
    if (confirmPasswordError) isFormValid = false;



    // If Form is Valid
    if (isFormValid) {
        const userData = {
            username: userName.value.trim(),
            contact: contactNumber.value.trim(),
            email: emailAddress.value.trim(),
            password: password.value.trim(),
        };
        console.log('Signup Successful:', userData);


        // Send POST request to the server
        fetch('http://localhost:3000/api/users', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(userData),
        })
            .then((response) => response.json())
            .then((jsonData) => {
                console.log(jsonData);
                if (jsonData.success) {
                    alert('Signup successful!');
                    window.location.href = 'signin.html'; // Redirect to the sign-in page
                } else {
                    alert(jsonData.message || 'Signup failed. Please try again.');
                }
            })
            .catch((error) => {
                console.error('Error:', error);
                alert('An error occurred. Please try again later.');
            });
        
    }


});





// Real-time Validation
userName.addEventListener('input', () => {
    userNameErrMsg.textContent = validateUsername(userName.value.trim());
});

contactNumber.addEventListener('input', () => {
    contactNumberErrMsg.textContent = validateContact(contactNumber.value.trim());
});

emailAddress.addEventListener('input', () => {
    emailAddressErrMsg.textContent = validateEmail(emailAddress.value.trim());
});

password.addEventListener('input', () => {
    passwordErrMsg.textContent = validatePassword(password.value.trim());
});

confirmPassword.addEventListener('input', () => {
    confirmPasswordErrMsg.textContent = validateConfirmPassword(password.value.trim(), confirmPassword.value.trim());
});





// Get elements for the password input and eye icon
const eye1 = document.getElementById('eye1');
const img1 = document.getElementById('eyeImg1');
const eye2 = document.getElementById('eye2');
const img2 = document.getElementById('eyeImg2');

// Function to show the visibility icon
function showIcon(eye){
    eye.classList.remove('hide');
}

// Function to hide the visibility icon
function hideIcon(password, img, eye){
    password.type = 'password';
    img.src = 'images/eye.png';
    if(password.value === ''){
        eye.classList.add('hide');
    }
}

// Show the visibility icon when the password input is focused
password.addEventListener('focus', () => {
    showIcon(eye1);
});
confirmPassword.addEventListener('focus', () => {
    showIcon(eye2);
});

// Hide the visibility icon when the password input loses focus
password.addEventListener('blur', () => {
    hideIcon(password, img1, eye1);
});
confirmPassword.addEventListener('blur', () => {
    hideIcon(confirmPassword, img2, eye2);
});

// Function to toggle password visibility
function toggleImg(password, img, event){
    // Prevent the click from causing the blur event
    event.preventDefault();
    event.stopPropagation();
    
    // Toggle password visibility
    const type = password.type === 'password' ? 'text' : 'password';
    password.type = type;

    // Change the icon based on the visibility state
    if (type === 'password') {
        img.src = 'images/eye.png';  // Change to closed-eye icon
    } else {
        img.src = 'images/visible.png';    // Change to open-eye icon
    }
    
    // Ensure the password field remains focused after clicking the icon
    password.focus();
}

// Toggle password visibility when the eye icon is clicked
eye1.addEventListener('mousedown', (event) => {
    toggleImg(password, img1, event);
});

eye2.addEventListener('mousedown', (event) => {
    toggleImg(confirmPassword, img2, event);
});



