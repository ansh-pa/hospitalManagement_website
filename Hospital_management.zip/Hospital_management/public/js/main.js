const navbar = {
    linkSearch: document.getElementById('linkSearch'),
    searchContainer: document.getElementById('searchContainer'),
    linkClose: document.getElementById('linkClose'),
    menuBtn: document.getElementById('menuBtn'),
    menuIcon: document.getElementById('menuIcon'),
    exploreBtn: document.getElementById('exploreBtn'),
    menuContainer: document.getElementById('menuContainer')
};

let overlayEle = document.getElementById('overlay');
let goToTopEle = document.getElementById('goToTop');



const overlayUtil = {
    show: () => {
        overlayEle.classList.add('show'); 
    },

    hide: () => {
        overlayEle.classList.remove('show');
    },

    toggle: () => {
        overlayEle.classList.toggle('show');
    }
};


function hideOverlay() {
    overlayUtil.hide();
    searchContainer.classList.add('hide');
    menuBtn.classList.remove('d-none'); 
    exploreBtn.classList.remove('d-none');
    linkSearch.classList.remove('d-none');
    menuContainer.classList.add('hide');
    menuIcon.classList.add('rotate');

    prompSearchBtn.classList.remove('hide');
    prompCloseBtn.classList.add('hide');
    prompSearchBar.classList.add('hide');
    prompLinkContainer.classList.add('hide');
    showPrompts();       
}

menuBtn.addEventListener('click', function(){
    overlayUtil.toggle();
    menuContainer.classList.toggle('hide');
    menuIcon.classList.toggle('rotate'); 
});

linkSearch.onclick = function(){
    overlayUtil.show();
    searchContainer.classList.remove('hide');
    menuBtn.classList.toggle('d-none'); 
    exploreBtn.classList.toggle('d-none');
    linkSearch.classList.toggle('d-none');
}

linkClose.onclick = function(){
    searchContainer.classList.add('hide');
    menuBtn.classList.toggle('d-none'); 
    exploreBtn.classList.toggle('d-none');
    linkSearch.classList.toggle('d-none');
    overlayUtil.hide();
}

overlayEle.onclick = function(){
    hideOverlay();
}

let resizeTimeout;
window.addEventListener('resize', function() {
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(hideOverlay, 200); // Delay the call by 200ms
});

// for navbar functionality finished


//   visible content animation started

// const cards = document.querySelectorAll('.card');
// const heading_ = document.querySelector('.heading_');

// // Create an Intersection Observer
// const observer = new IntersectionObserver((entries, observer) => {
//     entries.forEach(entry => {
//         if (entry.isIntersecting) {
//             // Add the 'visible' class to the card in view
//             entry.target.classList.add('visible');
//             // Stop observing the card once it's visible
//             observer.unobserve(entry.target);
//         }
//     });
// }, {
//     threshold: 0.1 // Trigger when 10% of the card is visible
// });

// // observe heading_
// observer.observe(heading_);

// // Observe each card
// cards.forEach(card => {
//     observer.observe(card);
// });

// visible content animation finished



// Function to handle fetching products based on category
// async function fetchProducts() {
//     try {
//         let response = await fetch('http://localhost:3000/api/users');
//         if (!response.ok) {
//             throw new Error('Network response was not ok ' + response.statusText);
//         }
//         let data = await response.json();
//         console.log(data); 
//         return data; // You can return the data if you want to use it elsewhere
//     } catch (error) {
//         console.error('There was a problem with the fetch operation:', error);
//     }
// }

// prompL1.addEventListener('click', (event) => {
//     fetchProducts().then(data => {
//         console.log(data);
//     });
// });
