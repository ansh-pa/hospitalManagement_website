// Select DOM elements
const form = document.getElementById('signinForm');
const username = document.getElementById('userName');
const password = document.getElementById('password');
const usernameErrMsg = document.getElementById('userNameErrMsg');
const passwordErrMsg = document.getElementById('passwordErrMsg');
const eye1 = document.getElementById('eye1');
const img1 = document.getElementById('eyeImg1');



// Utility to validate email
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Utility to validate contact number (10 digits)
function isValidContact(contact) {
    const contactRegex = /^\d{10}$/;
    return contactRegex.test(contact);
}




// Validate fields before form submission
function validateForm() {
    let isValid = true;

    // Validate Username
    if (username.value.trim() === '') {
        usernameErrMsg.textContent = 'Username is required.';
        isValid = false;
    } else if (!isValidEmail(username.value) && !isValidContact(username.value)) {
        usernameErrMsg.textContent = 'Enter a valid email or contact number.';
        isValid = false;
    } else {
        usernameErrMsg.textContent = ''; // Clear error message
    }

    // Validate Password
    if (password.value.trim() === '') {
        passwordErrMsg.textContent = 'Password is required.';
        isValid = false;
    } else if (password.value.length < 8) {
        passwordErrMsg.textContent = 'Password must be at least 8 characters.';
        isValid = false;
    } else {
        passwordErrMsg.textContent = ''; // Clear error message
    }

    return isValid;
}

// Handle form submission
form.addEventListener('submit', function (event) {
    event.preventDefault();

    // Perform form validation
    if (validateForm()) {
        // Prepare data for backend
        const credentials = {
            username: username.value.trim(),
            password: password.value.trim(),
        };

        // Send POST request to the backend for authentication
        fetch('http://localhost:3000/api/signup', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(credentials),
        })
            .then((response) => response.json())
            .then((data) => {
                console.log(data);
                if (data.success) {
                    // Redirect to the main page on successful login
                    window.location.href = 'index.html';
                } else {
                    // Show error message if login fails
                    alert(data.message || 'Invalid username or password.');
                }
            })
            .catch((error) => {
                console.error('Error:', error);
                alert('Something went wrong. Please try again later.');
            });
    }
});

// Real-time validation for username
username.addEventListener('input', function () {
    if (username.value.trim() === '') {
        usernameErrMsg.textContent = 'Username is required.';
    } else if (!isValidEmail(username.value) && !isValidContact(username.value)) {
        usernameErrMsg.textContent = 'Enter a valid email or contact number.';
    } else {
        usernameErrMsg.textContent = ''; // Clear error message
    }
});

// Real-time validation for password
password.addEventListener('input', function () {
    if (password.value.trim() === '') {
        passwordErrMsg.textContent = 'Password is required.';
    } else if (password.value.length < 8) {
        passwordErrMsg.textContent = 'Password must be at least 8 characters.';
    } else {
        passwordErrMsg.textContent = ''; // Clear error message
    }
});




// Show password visibility toggle
// Get elements for the password input and eye icon
const eye = document.getElementById('eye');
const img = document.getElementById('eyeImg');

// Function to show the visibility icon
function showIcon(eye){
    eye.classList.remove('hide');
}

// Function to hide the visibility icon
function hideIcon(password, img, eye){
    password.type = 'password';
    img.src = 'images/eye.png';
    if(password.value === ''){
        eye.classList.add('hide');
    }
}

// Show the visibility icon when the password input is focused
password.addEventListener('focus', () => {
    showIcon(eye);
});

// Hide the visibility icon when the password input loses focus
password.addEventListener('blur', () => {
    hideIcon(password, img, eye);
});

// Function to toggle password visibility
function toggleImg(password, img, event){
    // Prevent the click from causing the blur event
    event.preventDefault();
    event.stopPropagation();
    
    // Toggle password visibility
    const type = password.type === 'password' ? 'text' : 'password';
    password.type = type;

    // Change the icon based on the visibility state
    if (type === 'password') {
        img.src = 'images/eye.png';  // Change to closed-eye icon
    } else {
        img.src = 'images/visible.png';    // Change to open-eye icon
    }
    
    // Ensure the password field remains focused after clicking the icon
    password.focus();
}

// Toggle password visibility when the eye icon is clicked
eye.addEventListener('mousedown', (event) => {
    toggleImg(password, img, event);
});
